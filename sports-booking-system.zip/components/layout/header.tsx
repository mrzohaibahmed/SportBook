"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"

interface HeaderProps {
  user?: {
    name: string
    role: "owner" | "player"
  } | null
  onLogout?: () => void
}

export function Header({ user, onLogout }: HeaderProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <header className="bg-navy text-white shadow-lg">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link href="/" className="text-2xl font-bold text-orange">
            SportBook
          </Link>

          <nav className="hidden md:flex items-center space-x-6">
            <Link href="/" className="hover:text-orange transition-colors">
              Home
            </Link>
            <Link href="/grounds" className="hover:text-orange transition-colors">
              Grounds
            </Link>
            <Link href="/about" className="hover:text-orange transition-colors">
              About
            </Link>
            <Link href="/contact" className="hover:text-orange transition-colors">
              Contact
            </Link>

            {user ? (
              <div className="flex items-center space-x-4">
                <Link
                  href={user.role === "owner" ? "/owner-dashboard" : "/player-dashboard"}
                  className="hover:text-orange transition-colors"
                >
                  Dashboard
                </Link>
                <Button
                  onClick={onLogout}
                  variant="outline"
                  size="sm"
                  className="border-orange text-orange hover:bg-orange hover:text-white bg-transparent"
                >
                  Logout
                </Button>
              </div>
            ) : (
              <div className="flex items-center space-x-2">
                <Link href="/login">
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-orange text-orange hover:bg-orange hover:text-white bg-transparent"
                  >
                    Login
                  </Button>
                </Link>
                <Link href="/signup">
                  <Button size="sm" className="bg-orange hover:bg-orange/90 text-white">
                    Sign Up
                  </Button>
                </Link>
              </div>
            )}
          </nav>

          {/* Mobile menu button */}
          <button className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>
        </div>

        {/* Mobile menu */}
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t border-gray-700">
            <div className="flex flex-col space-y-2">
              <Link href="/" className="hover:text-orange transition-colors py-2">
                Home
              </Link>
              <Link href="/grounds" className="hover:text-orange transition-colors py-2">
                Grounds
              </Link>
              <Link href="/about" className="hover:text-orange transition-colors py-2">
                About
              </Link>
              <Link href="/contact" className="hover:text-orange transition-colors py-2">
                Contact
              </Link>
              {user ? (
                <>
                  <Link
                    href={user.role === "owner" ? "/owner-dashboard" : "/player-dashboard"}
                    className="hover:text-orange transition-colors py-2"
                  >
                    Dashboard
                  </Link>
                  <Button
                    onClick={onLogout}
                    variant="outline"
                    size="sm"
                    className="border-orange text-orange hover:bg-orange hover:text-white mt-2 bg-transparent"
                  >
                    Logout
                  </Button>
                </>
              ) : (
                <div className="flex flex-col space-y-2 mt-2">
                  <Link href="/login">
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full border-orange text-orange hover:bg-orange hover:text-white bg-transparent"
                    >
                      Login
                    </Button>
                  </Link>
                  <Link href="/signup">
                    <Button size="sm" className="w-full bg-orange hover:bg-orange/90 text-white">
                      Sign Up
                    </Button>
                  </Link>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </header>
  )
}
