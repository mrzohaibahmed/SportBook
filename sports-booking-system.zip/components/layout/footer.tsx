export function Footer() {
  return (
    <footer className="bg-navy text-white py-8 mt-auto">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-xl font-bold text-orange mb-4">SportBook</h3>
            <p className="text-gray-300">
              Your premier destination for booking indoor sports facilities. Play your favorite sports anytime,
              anywhere.
            </p>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2 text-gray-300">
              <li>
                <a href="/" className="hover:text-orange transition-colors">
                  Home
                </a>
              </li>
              <li>
                <a href="/grounds" className="hover:text-orange transition-colors">
                  Browse Grounds
                </a>
              </li>
              <li>
                <a href="/about" className="hover:text-orange transition-colors">
                  About Us
                </a>
              </li>
              <li>
                <a href="/contact" className="hover:text-orange transition-colors">
                  Contact
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-4">Contact Info</h4>
            <div className="text-gray-300 space-y-2">
              <p>Email: info@sportbook.com</p>
              <p>Phone: +1 (555) 123-4567</p>
              <p>Address: 123 Sports Ave, City, State 12345</p>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-300">
          <p>&copy; 2024 SportBook. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}
