"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

interface Ground {
  id: string
  name: string
  description: string
  address: string
  price: number
  sportType: string
  courts: number
  images: string[]
  rating: number
  isFavorite?: boolean
}

interface FavoritesSectionProps {
  favoriteGrounds: Ground[]
  onBookGround: (groundId: string) => void
  onRemoveFavorite: (groundId: string) => void
}

export function FavoritesSection({ favoriteGrounds, onBookGround, onRemoveFavorite }: FavoritesSectionProps) {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-navy mb-2">My Favorite Grounds</h2>
        <p className="text-gray-600">Quick access to your preferred sports facilities</p>
      </div>

      {favoriteGrounds.length === 0 ? (
        <Card>
          <CardContent className="p-12 text-center">
            <div className="text-gray-500 mb-4">
              <svg className="w-16 h-16 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={1}
                  d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"
                />
              </svg>
            </div>
            <h3 className="text-xl font-semibold text-gray-700 mb-2">No favorites yet</h3>
            <p className="text-gray-500">Start adding grounds to your favorites for quick access</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {favoriteGrounds.map((ground) => (
            <Card key={ground.id} className="overflow-hidden hover:shadow-xl transition-shadow duration-300">
              <div className="relative">
                <img
                  src={ground.images[0] || "/placeholder.svg"}
                  alt={ground.name}
                  className="w-full h-48 object-cover"
                />
                <Badge className="absolute top-3 left-3 bg-orange text-white">{ground.sportType}</Badge>
                <Button
                  onClick={() => onRemoveFavorite(ground.id)}
                  variant="ghost"
                  size="sm"
                  className="absolute top-3 right-3 text-red-500 hover:bg-white/20"
                >
                  ❤️
                </Button>
              </div>
              <CardHeader>
                <CardTitle className="text-navy">{ground.name}</CardTitle>
                <div className="flex items-center justify-between text-sm text-gray-600">
                  <span>📍 {ground.address.split(",")[0]}</span>
                  <span>⭐ {ground.rating}</span>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600 mb-4 line-clamp-2">{ground.description}</p>
                <div className="flex items-center justify-between mb-4">
                  <span className="text-lg font-semibold text-orange">PKR {ground.price}/hour</span>
                  <span className="text-sm text-gray-600">{ground.courts} courts</span>
                </div>
                <Button onClick={() => onBookGround(ground.id)} className="w-full bg-navy hover:bg-navy/90 text-white">
                  Book Now
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
