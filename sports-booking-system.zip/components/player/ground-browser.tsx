"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface Ground {
  id: string
  name: string
  description: string
  address: string
  price: number
  sportType: string
  courts: number
  images: string[]
  rating: number
  isFavorite?: boolean
}

interface GroundBrowserProps {
  grounds: Ground[]
  onBookGround: (groundId: string) => void
  onToggleFavorite: (groundId: string) => void
}

export function GroundBrowser({ grounds, onBookGround, onToggleFavorite }: GroundBrowserProps) {
  const [searchTerm, setSearchTerm] = useState("")
  const [sportFilter, setSportFilter] = useState("all")
  const [priceFilter, setPriceFilter] = useState("all")

  const filteredGrounds = grounds.filter((ground) => {
    const matchesSearch =
      ground.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ground.description.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesSport = sportFilter === "all" || ground.sportType === sportFilter
    const matchesPrice =
      priceFilter === "all" ||
      (priceFilter === "low" && ground.price <= 2000) ||
      (priceFilter === "medium" && ground.price > 2000 && ground.price <= 3000) ||
      (priceFilter === "high" && ground.price > 3000)

    return matchesSearch && matchesSport && matchesPrice
  })

  return (
    <div className="space-y-6">
      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="text-navy">Find Your Perfect Ground</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Input
                placeholder="Search grounds..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full"
              />
            </div>
            <div>
              <Select onValueChange={setSportFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="All Sports" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Sports</SelectItem>
                  <SelectItem value="Cricket">Cricket</SelectItem>
                  <SelectItem value="Football">Football</SelectItem>
                  <SelectItem value="Badminton">Badminton</SelectItem>
                  <SelectItem value="Tennis">Tennis</SelectItem>
                  <SelectItem value="Futsal">Futsal</SelectItem>
                  <SelectItem value="Multi-Sport">Multi-Sport</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Select onValueChange={setPriceFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="All Prices" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Prices</SelectItem>
                  <SelectItem value="low">Under PKR 2000</SelectItem>
                  <SelectItem value="medium">PKR 2000 - 3000</SelectItem>
                  <SelectItem value="high">Over PKR 3000</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Results */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredGrounds.map((ground) => (
          <Card key={ground.id} className="overflow-hidden hover:shadow-xl transition-shadow duration-300">
            <div className="relative">
              <img
                src={ground.images[0] || "/placeholder.svg"}
                alt={ground.name}
                className="w-full h-48 object-cover"
              />
              <Badge className="absolute top-3 left-3 bg-orange text-white">{ground.sportType}</Badge>
              <Button
                onClick={() => onToggleFavorite(ground.id)}
                variant="ghost"
                size="sm"
                className={`absolute top-3 right-3 ${
                  ground.isFavorite ? "text-red-500" : "text-white"
                } hover:bg-white/20`}
              >
                {ground.isFavorite ? "❤️" : "🤍"}
              </Button>
            </div>
            <CardHeader>
              <CardTitle className="text-navy">{ground.name}</CardTitle>
              <div className="flex items-center justify-between text-sm text-gray-600">
                <span>📍 {ground.address.split(",")[0]}</span>
                <span>⭐ {ground.rating}</span>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600 mb-4 line-clamp-2">{ground.description}</p>
              <div className="flex items-center justify-between mb-4">
                <span className="text-lg font-semibold text-orange">PKR {ground.price}/hour</span>
                <span className="text-sm text-gray-600">{ground.courts} courts</span>
              </div>
              <Button onClick={() => onBookGround(ground.id)} className="w-full bg-navy hover:bg-navy/90 text-white">
                Book Now
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredGrounds.length === 0 && (
        <Card>
          <CardContent className="p-12 text-center">
            <div className="text-gray-500 mb-4">
              <svg className="w-16 h-16 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={1}
                  d="M9.172 16.172a4 4 0 015.656 0M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                />
              </svg>
            </div>
            <h3 className="text-xl font-semibold text-gray-700 mb-2">No grounds found</h3>
            <p className="text-gray-500">Try adjusting your search filters</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
