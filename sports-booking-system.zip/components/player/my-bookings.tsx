"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

interface Booking {
  id: string
  groundId: string
  groundName: string
  groundImage: string
  date: string
  startTime: string
  endTime: string
  court: number
  status: "confirmed" | "pending" | "cancelled" | "completed"
  totalPrice: number
  canReview?: boolean
}

interface MyBookingsProps {
  bookings: Booking[]
  onCancelBooking: (bookingId: string) => void
  onLeaveReview: (groundId: string, groundName: string) => void
}

export function MyBookings({ bookings, onCancelBooking, onLeaveReview }: MyBookingsProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "confirmed":
        return "bg-accent-green text-white"
      case "pending":
        return "bg-orange text-white"
      case "cancelled":
        return "bg-red-600 text-white"
      case "completed":
        return "bg-accent-blue text-white"
      default:
        return "bg-gray-500 text-white"
    }
  }

  const upcomingBookings = bookings.filter((b) => b.status === "confirmed" || b.status === "pending")
  const pastBookings = bookings.filter((b) => b.status === "completed" || b.status === "cancelled")

  return (
    <div className="space-y-8">
      {/* Upcoming Bookings */}
      <div>
        <h2 className="text-2xl font-bold text-navy mb-6">Upcoming Bookings</h2>
        {upcomingBookings.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <div className="text-gray-500 mb-4">
                <svg className="w-12 h-12 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={1}
                    d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                  />
                </svg>
              </div>
              <h3 className="text-lg font-semibold text-gray-700 mb-2">No upcoming bookings</h3>
              <p className="text-gray-500">Book a ground to see your reservations here</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {upcomingBookings.map((booking) => (
              <Card key={booking.id} className="border-l-4 border-l-orange">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <img
                      src={booking.groundImage || "/placeholder.svg"}
                      alt={booking.groundName}
                      className="w-20 h-20 object-cover rounded-lg"
                    />
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <h3 className="text-lg font-semibold text-navy">{booking.groundName}</h3>
                          <Badge className={getStatusColor(booking.status)}>
                            {booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
                          </Badge>
                        </div>
                        <div className="text-right">
                          <div className="text-lg font-semibold text-orange">PKR {booking.totalPrice}</div>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm text-gray-600 mb-4">
                        <div>
                          <span className="font-medium">Date:</span>
                          <p>{new Date(booking.date).toLocaleDateString()}</p>
                        </div>
                        <div>
                          <span className="font-medium">Time:</span>
                          <p>
                            {booking.startTime} - {booking.endTime}
                          </p>
                        </div>
                        <div>
                          <span className="font-medium">Court:</span>
                          <p>Court {booking.court}</p>
                        </div>
                        <div className="flex gap-2">
                          {booking.status === "confirmed" && (
                            <Button
                              onClick={() => onCancelBooking(booking.id)}
                              variant="outline"
                              size="sm"
                              className="text-red-600 border-red-600 hover:bg-red-600 hover:text-white"
                            >
                              Cancel
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Past Bookings */}
      <div>
        <h2 className="text-2xl font-bold text-navy mb-6">Past Bookings</h2>
        {pastBookings.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <div className="text-gray-500 mb-4">
                <svg className="w-12 h-12 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={1}
                    d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                  />
                </svg>
              </div>
              <h3 className="text-lg font-semibold text-gray-700 mb-2">No past bookings</h3>
              <p className="text-gray-500">Your booking history will appear here</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {pastBookings.map((booking) => (
              <Card key={booking.id} className="border-l-4 border-l-gray-300">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <img
                      src={booking.groundImage || "/placeholder.svg"}
                      alt={booking.groundName}
                      className="w-20 h-20 object-cover rounded-lg opacity-75"
                    />
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <h3 className="text-lg font-semibold text-navy">{booking.groundName}</h3>
                          <Badge className={getStatusColor(booking.status)}>
                            {booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
                          </Badge>
                        </div>
                        <div className="text-right">
                          <div className="text-lg font-semibold text-gray-600">PKR {booking.totalPrice}</div>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm text-gray-600 mb-4">
                        <div>
                          <span className="font-medium">Date:</span>
                          <p>{new Date(booking.date).toLocaleDateString()}</p>
                        </div>
                        <div>
                          <span className="font-medium">Time:</span>
                          <p>
                            {booking.startTime} - {booking.endTime}
                          </p>
                        </div>
                        <div>
                          <span className="font-medium">Court:</span>
                          <p>Court {booking.court}</p>
                        </div>
                        <div className="flex gap-2">
                          {booking.status === "completed" && booking.canReview && (
                            <Button
                              onClick={() => onLeaveReview(booking.groundId, booking.groundName)}
                              variant="outline"
                              size="sm"
                              className="text-accent-blue border-accent-blue hover:bg-accent-blue hover:text-white"
                            >
                              Leave Review
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
