import { Card, CardContent } from "@/components/ui/card"

const features = [
  {
    icon: "🏟️",
    title: "Premium Facilities",
    description:
      "Access to top-quality indoor sports facilities with modern amenities and professional-grade equipment.",
  },
  {
    icon: "📱",
    title: "Easy Booking",
    description: "Book your favorite courts in just a few clicks. Real-time availability and instant confirmation.",
  },
  {
    icon: "⭐",
    title: "Verified Reviews",
    description: "Read authentic reviews from other players to choose the best facilities for your needs.",
  },
  {
    icon: "🤖",
    title: "AI Recommendations",
    description: "Get personalized ground suggestions based on your preferences, location, and playing schedule.",
  },
]

export function FeaturesSection() {
  return (
    <section className="py-20 bg-muted-gray">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-navy mb-4">Why Choose SportBook?</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            We make it easy to find and book the perfect sports facility for your game
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <Card key={index} className="text-center hover:shadow-lg transition-shadow duration-300">
              <CardContent className="p-6">
                <div className="text-4xl mb-4">{feature.icon}</div>
                <h3 className="text-xl font-semibold text-navy mb-3">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
