"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export function AIRecommendation() {
  const [preferences, setPreferences] = useState({
    sport: "",
    day: "",
    time: "",
  })

  const handleGetRecommendations = () => {
    // This would typically call an AI service
    alert(`Getting recommendations for ${preferences.sport} on ${preferences.day} at ${preferences.time}`)
  }

  return (
    <section className="py-20 bg-navy text-white">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4">AI-Powered Recommendations</h2>
            <p className="text-xl text-gray-300">
              Let our AI find the perfect sports facility based on your preferences
            </p>
          </div>

          <Card className="bg-white/10 border-white/20 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-white text-center">Find Your Perfect Match</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="sport" className="text-white">
                    Preferred Sport
                  </Label>
                  <Select onValueChange={(value) => setPreferences({ ...preferences, sport: value })}>
                    <SelectTrigger className="bg-white/10 border-white/20 text-white">
                      <SelectValue placeholder="Select sport" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="cricket">Cricket</SelectItem>
                      <SelectItem value="football">Football</SelectItem>
                      <SelectItem value="badminton">Badminton</SelectItem>
                      <SelectItem value="tennis">Tennis</SelectItem>
                      <SelectItem value="futsal">Futsal</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="day" className="text-white">
                    Preferred Day
                  </Label>
                  <Select onValueChange={(value) => setPreferences({ ...preferences, day: value })}>
                    <SelectTrigger className="bg-white/10 border-white/20 text-white">
                      <SelectValue placeholder="Select day" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="monday">Monday</SelectItem>
                      <SelectItem value="tuesday">Tuesday</SelectItem>
                      <SelectItem value="wednesday">Wednesday</SelectItem>
                      <SelectItem value="thursday">Thursday</SelectItem>
                      <SelectItem value="friday">Friday</SelectItem>
                      <SelectItem value="saturday">Saturday</SelectItem>
                      <SelectItem value="sunday">Sunday</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="time" className="text-white">
                    Preferred Time
                  </Label>
                  <Input
                    id="time"
                    type="time"
                    className="bg-white/10 border-white/20 text-white"
                    onChange={(e) => setPreferences({ ...preferences, time: e.target.value })}
                  />
                </div>
              </div>

              <div className="text-center">
                <Button
                  onClick={handleGetRecommendations}
                  size="lg"
                  className="bg-orange hover:bg-orange/90 text-white px-8"
                >
                  Get AI Recommendations
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
