import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"

const popularGrounds = [
  {
    id: 1,
    name: "Elite Sports Complex",
    image: "/modern-indoor-sports-complex-with-multiple-courts.jpg",
    sport: "Multi-Sport",
    location: "Downtown",
    price: "PKR 2500/hour",
    rating: 4.8,
    courts: 4,
  },
  {
    id: 2,
    name: "Champions Cricket Arena",
    image: "/indoor-cricket-pitch-with-professional-lighting.jpg",
    sport: "Cricket",
    location: "Sports District",
    price: "PKR 3000/hour",
    rating: 4.9,
    courts: 2,
  },
  {
    id: 3,
    name: "Futsal Pro Center",
    image: "/professional-futsal-court-with-blue-and-orange-col.jpg",
    sport: "Futsal",
    location: "City Center",
    price: "PKR 2000/hour",
    rating: 4.7,
    courts: 3,
  },
]

export function PopularGrounds() {
  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-navy mb-4">Popular Grounds</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Discover the most booked sports facilities in your area
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {popularGrounds.map((ground) => (
            <Card key={ground.id} className="overflow-hidden hover:shadow-xl transition-shadow duration-300">
              <div className="relative">
                <img src={ground.image || "/placeholder.svg"} alt={ground.name} className="w-full h-48 object-cover" />
                <Badge className="absolute top-3 left-3 bg-orange text-white">{ground.sport}</Badge>
              </div>
              <CardHeader>
                <CardTitle className="text-navy">{ground.name}</CardTitle>
                <div className="flex items-center justify-between text-sm text-gray-600">
                  <span>📍 {ground.location}</span>
                  <span>⭐ {ground.rating}</span>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between mb-4">
                  <span className="text-lg font-semibold text-orange">{ground.price}</span>
                  <span className="text-sm text-gray-600">{ground.courts} courts available</span>
                </div>
                <Link href={`/grounds/${ground.id}`}>
                  <Button className="w-full bg-navy hover:bg-navy/90 text-white">View Details</Button>
                </Link>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <Link href="/grounds">
            <Button
              size="lg"
              variant="outline"
              className="border-navy text-navy hover:bg-navy hover:text-white bg-transparent"
            >
              View All Grounds
            </Button>
          </Link>
        </div>
      </div>
    </section>
  )
}
