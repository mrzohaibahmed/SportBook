"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import Link from "next/link"

const backgroundImages = [
  "/images/sports-field-night.jpg",
  "/images/football-on-turf.jpg",
  "/images/indoor-futsal-court.jpg",
]

const sports = ["Cricket", "Football", "Badminton", "Tennis"]

export function HeroSection() {
  const [currentImageIndex, setCurrentImageIndex] = useState(0)
  const [currentSportIndex, setCurrentSportIndex] = useState(0)

  // Change background image every 4 seconds
  useEffect(() => {
    const imageInterval = setInterval(() => {
      setCurrentImageIndex((prev) => (prev + 1) % backgroundImages.length)
    }, 4000)

    return () => clearInterval(imageInterval)
  }, [])

  // Change sport text every 3 seconds
  useEffect(() => {
    const sportInterval = setInterval(() => {
      setCurrentSportIndex((prev) => (prev + 1) % sports.length)
    }, 3000)

    return () => clearInterval(sportInterval)
  }, [])

  return (
    <section className="relative h-screen flex items-center overflow-hidden">
      {/* Background Images */}
      <div className="absolute inset-0">
        {backgroundImages.map((image, index) => (
          <div
            key={index}
            className={`absolute inset-0 transition-all duration-2000 ease-in-out transform ${
              index === currentImageIndex ? "opacity-100 scale-100" : "opacity-0 scale-105"
            }`}
            style={{
              backgroundImage: `url(${image})`,
              backgroundSize: "cover",
              backgroundPosition: "center",
            }}
          />
        ))}
        {/* Dark overlay for better text readability */}
        <div className="absolute inset-0 bg-black/40" />
      </div>

      {/* Hero Content */}
      <div className="relative z-10 text-white px-4 w-full">
        <div className="max-w-7xl mx-auto">
          <div className="text-center">
            <h1 className="text-5xl md:text-7xl font-bold mb-4 slide-in-delayed">
              Play Any Sport,{""}
              <span className="text-orange inline-block min-w-[280px] transition-all duration-500 ease-in-out">
                {sports[currentSportIndex]}
              </span>
            </h1>
            <h2 className="text-4xl md:text-6xl font-semibold mb-8 slide-in-delayed-2">Book Online</h2>
            <p className="text-xl md:text-2xl mb-12 text-gray-200 max-w-xl mx-auto slide-in-delayed-3">
              Discover and book premium indoor sports facilities in your area. From cricket to tennis, find your perfect
              court today.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 slide-in-delayed-4 justify-center">
              <Link href="/grounds">
                <Button
                  size="lg"
                  className="bg-orange hover:bg-orange/90 text-white px-8 py-4 text-lg transition-all duration-300 hover:scale-105"
                >
                  Browse Grounds
                </Button>
              </Link>
              <Link href="/signup">
                <Button
                  size="lg"
                  variant="outline"
                  className="border-white text-white hover:bg-white hover:text-navy px-8 py-4 text-lg bg-transparent transition-all duration-300 hover:scale-105"
                >
                  Get Started
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white animate-bounce">
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
        </svg>
      </div>
    </section>
  )
}
