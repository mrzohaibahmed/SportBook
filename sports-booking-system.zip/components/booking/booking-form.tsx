"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"

interface BookingFormProps {
  groundName: string
  selectedDate: string
  selectedSlot: { startTime: string; endTime: string }
  selectedCourt: number
  totalPrice: number
  onSubmitBooking: (bookingData: {
    playerName: string
    playerEmail: string
    playerPhone: string
    specialRequests: string
    agreedToTerms: boolean
  }) => void
  onCancel: () => void
}

export function BookingForm({
  groundName,
  selectedDate,
  selectedSlot,
  selectedCourt,
  totalPrice,
  onSubmitBooking,
  onCancel,
}: BookingFormProps) {
  const [formData, setFormData] = useState({
    playerName: "",
    playerEmail: "",
    playerPhone: "",
    specialRequests: "",
    agreedToTerms: false,
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!formData.agreedToTerms) {
      alert("Please agree to the terms and conditions")
      return
    }
    onSubmitBooking(formData)
  }

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader className="bg-navy text-white rounded-t-lg">
        <CardTitle className="text-2xl">Complete Your Booking</CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        {/* Booking Summary */}
        <Card className="mb-6 bg-muted-gray">
          <CardContent className="p-4">
            <h3 className="font-semibold text-navy mb-2">Booking Details</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <div>
                <span className="font-medium">Ground:</span>
                <p>{groundName}</p>
              </div>
              <div>
                <span className="font-medium">Date:</span>
                <p>{new Date(selectedDate).toLocaleDateString()}</p>
              </div>
              <div>
                <span className="font-medium">Time:</span>
                <p>
                  {selectedSlot.startTime} - {selectedSlot.endTime}
                </p>
              </div>
              <div>
                <span className="font-medium">Court:</span>
                <p>Court {selectedCourt}</p>
              </div>
            </div>
            <div className="mt-4 pt-4 border-t border-gray-300">
              <div className="flex justify-between items-center">
                <span className="font-semibold">Total Amount:</span>
                <span className="text-2xl font-bold text-orange">${totalPrice}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Booking Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="playerName">Full Name *</Label>
              <Input
                id="playerName"
                value={formData.playerName}
                onChange={(e) => setFormData({ ...formData, playerName: e.target.value })}
                required
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="playerEmail">Email Address *</Label>
              <Input
                id="playerEmail"
                type="email"
                value={formData.playerEmail}
                onChange={(e) => setFormData({ ...formData, playerEmail: e.target.value })}
                required
                className="mt-1"
              />
            </div>
          </div>

          <div>
            <Label htmlFor="playerPhone">Phone Number *</Label>
            <Input
              id="playerPhone"
              type="tel"
              value={formData.playerPhone}
              onChange={(e) => setFormData({ ...formData, playerPhone: e.target.value })}
              required
              className="mt-1"
            />
          </div>

          <div>
            <Label htmlFor="specialRequests">Special Requests (Optional)</Label>
            <Textarea
              id="specialRequests"
              value={formData.specialRequests}
              onChange={(e) => setFormData({ ...formData, specialRequests: e.target.value })}
              className="mt-1"
              rows={3}
              placeholder="Any special equipment needs, accessibility requirements, etc."
            />
          </div>

          <div className="flex items-center space-x-2">
            <Checkbox
              id="terms"
              checked={formData.agreedToTerms}
              onCheckedChange={(checked) => setFormData({ ...formData, agreedToTerms: checked as boolean })}
            />
            <Label htmlFor="terms" className="text-sm">
              I agree to the{" "}
              <a href="/terms" className="text-orange hover:underline">
                terms and conditions
              </a>{" "}
              and{" "}
              <a href="/privacy" className="text-orange hover:underline">
                privacy policy
              </a>
            </Label>
          </div>

          <div className="flex gap-4 pt-6">
            <Button type="submit" className="flex-1 bg-orange hover:bg-orange/90 text-white" size="lg">
              Confirm Booking - ${totalPrice}
            </Button>
            <Button type="button" variant="outline" onClick={onCancel} className="flex-1 bg-transparent" size="lg">
              Cancel
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}
