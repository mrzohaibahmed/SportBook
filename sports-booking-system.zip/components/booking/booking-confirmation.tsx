"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"

interface BookingConfirmationProps {
  bookingId: string
  groundName: string
  groundImage: string
  selectedDate: string
  selectedSlot: { startTime: string; endTime: string }
  selectedCourt: number
  totalPrice: number
  playerName: string
  playerEmail: string
}

export function BookingConfirmation({
  bookingId,
  groundName,
  groundImage,
  selectedDate,
  selectedSlot,
  selectedCourt,
  totalPrice,
  playerName,
  playerEmail,
}: BookingConfirmationProps) {
  return (
    <div className="max-w-2xl mx-auto space-y-6">
      {/* Success Message */}
      <Card className="border-accent-green">
        <CardContent className="p-8 text-center">
          <div className="text-accent-green mb-4">
            <svg className="w-16 h-16 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h2 className="text-2xl font-bold text-navy mb-2">Booking Confirmed!</h2>
          <p className="text-gray-600">
            Your booking has been successfully confirmed. You will receive a confirmation email shortly.
          </p>
        </CardContent>
      </Card>

      {/* Booking Details */}
      <Card>
        <CardHeader className="bg-navy text-white rounded-t-lg">
          <div className="flex items-center justify-between">
            <CardTitle>Booking Details</CardTitle>
            <Badge className="bg-accent-green text-white">Confirmed</Badge>
          </div>
        </CardHeader>
        <CardContent className="p-6">
          <div className="flex items-start gap-4 mb-6">
            <img
              src={groundImage || "/placeholder.svg"}
              alt={groundName}
              className="w-20 h-20 object-cover rounded-lg"
            />
            <div className="flex-1">
              <h3 className="text-xl font-semibold text-navy">{groundName}</h3>
              <p className="text-gray-600">Booking ID: #{bookingId}</p>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-orange">${totalPrice}</div>
              <div className="text-sm text-gray-600">Total Paid</div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <h4 className="font-semibold text-navy mb-2">Schedule</h4>
                <div className="space-y-1 text-sm">
                  <p>
                    <span className="font-medium">Date:</span> {new Date(selectedDate).toLocaleDateString()}
                  </p>
                  <p>
                    <span className="font-medium">Time:</span> {selectedSlot.startTime} - {selectedSlot.endTime}
                  </p>
                  <p>
                    <span className="font-medium">Court:</span> Court {selectedCourt}
                  </p>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <h4 className="font-semibold text-navy mb-2">Contact Information</h4>
                <div className="space-y-1 text-sm">
                  <p>
                    <span className="font-medium">Name:</span> {playerName}
                  </p>
                  <p>
                    <span className="font-medium">Email:</span> {playerEmail}
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-6 p-4 bg-muted-gray rounded-lg">
            <h4 className="font-semibold text-navy mb-2">Important Information</h4>
            <ul className="text-sm text-gray-600 space-y-1">
              <li>• Please arrive 10 minutes before your scheduled time</li>
              <li>• Bring valid ID and confirmation email</li>
              <li>• Cancellations must be made at least 2 hours in advance</li>
              <li>• Contact the facility directly for any changes or questions</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <div className="flex flex-col sm:flex-row gap-4">
        <Link href="/player-dashboard" className="flex-1">
          <Button className="w-full bg-navy hover:bg-navy/90 text-white" size="lg">
            View My Bookings
          </Button>
        </Link>
        <Link href="/grounds" className="flex-1">
          <Button variant="outline" className="w-full bg-transparent" size="lg">
            Book Another Ground
          </Button>
        </Link>
      </div>
    </div>
  )
}
