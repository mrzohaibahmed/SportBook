"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"

interface TimeSlot {
  id: string
  startTime: string
  endTime: string
  isAvailable: boolean
  isBlocked?: boolean
  blockReason?: string
}

interface Court {
  id: number
  name: string
  isAvailable: boolean
}

interface TimeSlotSelectorProps {
  selectedDate: string
  timeSlots: TimeSlot[]
  courts: Court[]
  pricePerHour: number
  onSlotSelect: (slotId: string, courtId: number) => void
  selectedSlot: string | null
  selectedCourt: number | null
}

export function TimeSlotSelector({
  selectedDate,
  timeSlots,
  courts,
  pricePerHour,
  onSlotSelect,
  selectedSlot,
  selectedCourt,
}: TimeSlotSelectorProps) {
  const [hoveredSlot, setHoveredSlot] = useState<string | null>(null)

  const availableSlots = timeSlots.filter((slot) => slot.isAvailable && !slot.isBlocked)
  const availableCourts = courts.filter((court) => court.isAvailable)

  const calculatePrice = () => {
    if (!selectedSlot) return 0
    const slot = timeSlots.find((s) => s.id === selectedSlot)
    if (!slot) return 0

    const start = new Date(`2000-01-01 ${slot.startTime}`)
    const end = new Date(`2000-01-01 ${slot.endTime}`)
    const hours = (end.getTime() - start.getTime()) / (1000 * 60 * 60)
    return hours * pricePerHour
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-navy">
            Available Time Slots - {new Date(selectedDate).toLocaleDateString()}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {availableSlots.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <p>No available time slots for this date.</p>
              <p className="text-sm mt-2">Please select a different date.</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
              {timeSlots.map((slot) => (
                <Button
                  key={slot.id}
                  variant={selectedSlot === slot.id ? "default" : "outline"}
                  className={`p-3 h-auto flex flex-col ${
                    !slot.isAvailable || slot.isBlocked
                      ? "opacity-50 cursor-not-allowed"
                      : selectedSlot === slot.id
                        ? "bg-orange hover:bg-orange/90 text-white"
                        : "hover:bg-orange/10 hover:border-orange"
                  }`}
                  onClick={() => slot.isAvailable && !slot.isBlocked && onSlotSelect(slot.id, selectedCourt || 1)}
                  disabled={!slot.isAvailable || slot.isBlocked}
                  onMouseEnter={() => setHoveredSlot(slot.id)}
                  onMouseLeave={() => setHoveredSlot(null)}
                >
                  <div className="text-sm font-medium">
                    {slot.startTime} - {slot.endTime}
                  </div>
                  {slot.isBlocked && (
                    <Badge variant="destructive" className="text-xs mt-1">
                      Blocked
                    </Badge>
                  )}
                  {!slot.isAvailable && !slot.isBlocked && (
                    <Badge variant="secondary" className="text-xs mt-1">
                      Booked
                    </Badge>
                  )}
                  {hoveredSlot === slot.id && slot.isBlocked && slot.blockReason && (
                    <div className="absolute z-10 bg-black text-white text-xs p-2 rounded mt-8 max-w-xs">
                      {slot.blockReason}
                    </div>
                  )}
                </Button>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {selectedSlot && availableCourts.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-navy">Select Court</CardTitle>
          </CardHeader>
          <CardContent>
            <RadioGroup
              value={selectedCourt?.toString()}
              onValueChange={(value) => onSlotSelect(selectedSlot, Number.parseInt(value))}
            >
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {availableCourts.map((court) => (
                  <div key={court.id} className="flex items-center space-x-2">
                    <RadioGroupItem value={court.id.toString()} id={`court-${court.id}`} />
                    <Label htmlFor={`court-${court.id}`} className="flex-1 cursor-pointer">
                      <Card className="p-4 hover:bg-muted-gray/50 transition-colors">
                        <div className="flex items-center justify-between">
                          <span className="font-medium">{court.name}</span>
                          <Badge variant="outline" className="text-accent-green border-accent-green">
                            Available
                          </Badge>
                        </div>
                      </Card>
                    </Label>
                  </div>
                ))}
              </div>
            </RadioGroup>
          </CardContent>
        </Card>
      )}

      {selectedSlot && selectedCourt && (
        <Card className="border-orange">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold text-navy">Booking Summary</h3>
                <p className="text-gray-600">
                  {timeSlots.find((s) => s.id === selectedSlot)?.startTime} -{" "}
                  {timeSlots.find((s) => s.id === selectedSlot)?.endTime} on{" "}
                  {new Date(selectedDate).toLocaleDateString()}
                </p>
                <p className="text-gray-600">Court {selectedCourt}</p>
              </div>
              <div className="text-right">
                <div className="text-2xl font-bold text-orange">${calculatePrice()}</div>
                <div className="text-sm text-gray-600">Total Price</div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
