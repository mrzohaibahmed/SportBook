"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface Ground {
  id: string
  name: string
  description: string
  address: string
  price: number
  sportType: string
  courts: number
  images: string[]
}

interface AddGroundFormProps {
  onAddGround: (ground: Omit<Ground, "id">) => void
  onCancel: () => void
  initialData?: Ground | null
}

export function AddGroundForm({ onAddGround, onCancel, initialData }: AddGroundFormProps) {
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    address: "",
    price: "",
    sportType: "",
    courts: "1",
    images: [] as string[],
  })

  const addressInputRef = useRef<HTMLInputElement>(null)
  const [isMapLoaded, setIsMapLoaded] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (initialData) {
      setFormData({
        name: initialData.name,
        description: initialData.description,
        address: initialData.address,
        price: initialData.price.toString(),
        sportType: initialData.sportType,
        courts: initialData.courts.toString(),
        images: initialData.images,
      })
    }
  }, [initialData])

  useEffect(() => {
    const loadGoogleMaps = () => {
      if (window.google && window.google.maps) {
        initializeAutocomplete()
        return
      }

      const script = document.createElement("script")
      script.src = `https://maps.googleapis.com/maps/api/js?key=YOUR_GOOGLE_MAPS_API_KEY&libraries=places`
      script.async = true
      script.defer = true
      script.onload = () => {
        setIsMapLoaded(true)
        initializeAutocomplete()
      }
      document.head.appendChild(script)
    }

    const initializeAutocomplete = () => {
      if (addressInputRef.current && window.google) {
        const autocomplete = new window.google.maps.places.Autocomplete(addressInputRef.current, {
          types: ["establishment", "geocode"],
          componentRestrictions: { country: "pk" }, // Restrict to Pakistan
        })

        autocomplete.addListener("place_changed", () => {
          const place = autocomplete.getPlace()
          if (place.formatted_address) {
            setFormData((prev) => ({
              ...prev,
              address: place.formatted_address,
            }))
          }
        })
      }
    }

    loadGoogleMaps()
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onAddGround({
      name: formData.name,
      description: formData.description,
      address: formData.address,
      price: Number(formData.price),
      sportType: formData.sportType,
      courts: Number(formData.courts),
      images: formData.images.length > 0 ? formData.images : ["/placeholder.svg?key=default"],
    })
  }

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (files) {
      Array.from(files).forEach((file) => {
        if (file.type.startsWith("image/")) {
          const reader = new FileReader()
          reader.onload = (event) => {
            const imageDataUrl = event.target?.result as string
            setFormData((prev) => ({
              ...prev,
              images: [...prev.images, imageDataUrl],
            }))
          }
          reader.readAsDataURL(file)
        }
      })
    }
    // Reset file input
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  const handleImageAdd = () => {
    fileInputRef.current?.click()
  }

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader className="bg-navy text-white rounded-t-lg">
        <CardTitle className="text-2xl">{initialData ? "Edit Ground" : "Add New Ground"}</CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="name">Ground Name</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              required
              className="mt-1"
            />
          </div>

          <div>
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              required
              className="mt-1"
              rows={3}
            />
          </div>

          <div>
            <Label htmlFor="address">Address</Label>
            <Input
              ref={addressInputRef}
              id="address"
              value={formData.address}
              onChange={(e) => setFormData({ ...formData, address: e.target.value })}
              required
              className="mt-1"
              placeholder="Start typing to search for address..."
            />
            <p className="text-sm text-gray-500 mt-1">
              {isMapLoaded ? "Start typing to get address suggestions from Google Maps" : "Loading Google Maps..."}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="price">Price per Hour (PKR)</Label>
              <Input
                id="price"
                type="number"
                value={formData.price}
                onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                required
                className="mt-1"
                min="1"
              />
            </div>

            <div>
              <Label htmlFor="courts">Number of Courts</Label>
              <Select value={formData.courts} onValueChange={(value) => setFormData({ ...formData, courts: value })}>
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="Select courts" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">1 Court</SelectItem>
                  <SelectItem value="2">2 Courts</SelectItem>
                  <SelectItem value="3">3 Courts</SelectItem>
                  <SelectItem value="4">4 Courts</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label htmlFor="sportType">Sport Type</Label>
            <Select
              value={formData.sportType}
              onValueChange={(value) => setFormData({ ...formData, sportType: value })}
            >
              <SelectTrigger className="mt-1">
                <SelectValue placeholder="Select sport type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Cricket">Cricket</SelectItem>
                <SelectItem value="Football">Football</SelectItem>
                <SelectItem value="Badminton">Badminton</SelectItem>
                <SelectItem value="Tennis">Tennis</SelectItem>
                <SelectItem value="Futsal">Futsal</SelectItem>
                <SelectItem value="Multi-Sport">Multi-Sport</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label>Ground Images</Label>
            <div className="mt-2 space-y-2">
              {formData.images.map((image, index) => (
                <div key={index} className="flex items-center gap-2">
                  <img
                    src={image || "/placeholder.svg"}
                    alt={`Ground ${index + 1}`}
                    className="w-16 h-16 object-cover rounded"
                  />
                  <span className="text-sm text-gray-600 flex-1">
                    {image.startsWith("data:") ? `Image ${index + 1} (from device)` : image}
                  </span>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() =>
                      setFormData({
                        ...formData,
                        images: formData.images.filter((_, i) => i !== index),
                      })
                    }
                  >
                    Remove
                  </Button>
                </div>
              ))}

              {/* Hidden file input for image upload */}
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                multiple
                onChange={handleImageUpload}
                className="hidden"
              />

              <Button type="button" variant="outline" onClick={handleImageAdd} className="w-full bg-transparent">
                📷 Upload Images from Device
              </Button>
              <p className="text-sm text-gray-500">Click to select multiple images from your device</p>
            </div>
          </div>

          <div className="flex gap-4 pt-4">
            <Button type="submit" className="flex-1 bg-orange hover:bg-orange/90 text-white">
              {initialData ? "Update Ground" : "Add Ground"}
            </Button>
            <Button type="button" variant="outline" onClick={onCancel} className="flex-1 bg-transparent">
              Cancel
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}
