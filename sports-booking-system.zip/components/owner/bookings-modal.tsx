"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

interface Booking {
  id: string
  playerName: string
  playerEmail: string
  date: string
  startTime: string
  endTime: string
  court: number
  status: "confirmed" | "pending" | "cancelled"
  totalPrice: number
}

interface BookingsModalProps {
  groundId: string
  groundName: string
  bookings: Booking[]
  onClose: () => void
}

export function BookingsModal({ groundId, groundName, bookings, onClose }: BookingsModalProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "confirmed":
        return "bg-accent-green text-white"
      case "pending":
        return "bg-orange text-white"
      case "cancelled":
        return "bg-red-600 text-white"
      default:
        return "bg-gray-500 text-white"
    }
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-4xl max-h-[80vh] overflow-hidden">
        <CardHeader className="bg-navy text-white rounded-t-lg">
          <div className="flex items-center justify-between">
            <CardTitle>Bookings - {groundName}</CardTitle>
            <Button onClick={onClose} variant="ghost" size="sm" className="text-white hover:bg-white/20">
              ✕
            </Button>
          </div>
        </CardHeader>
        <CardContent className="p-6 overflow-y-auto">
          {bookings.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <p>No bookings found for this ground.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {bookings.map((booking) => (
                <Card key={booking.id} className="border-l-4 border-l-orange">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="space-y-2">
                        <div className="flex items-center gap-3">
                          <h4 className="font-semibold text-navy">{booking.playerName}</h4>
                          <Badge className={getStatusColor(booking.status)}>
                            {booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-600">{booking.playerEmail}</p>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                          <div>
                            <span className="font-medium">Date:</span>
                            <p>{new Date(booking.date).toLocaleDateString()}</p>
                          </div>
                          <div>
                            <span className="font-medium">Time:</span>
                            <p>
                              {booking.startTime} - {booking.endTime}
                            </p>
                          </div>
                          <div>
                            <span className="font-medium">Court:</span>
                            <p>Court {booking.court}</p>
                          </div>
                          <div>
                            <span className="font-medium">Total:</span>
                            <p className="text-orange font-semibold">PKR {booking.totalPrice}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
