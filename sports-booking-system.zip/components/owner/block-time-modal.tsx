"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface BlockTimeModalProps {
  groundId: string
  groundName: string
  onBlock: (blockData: {
    groundId: string
    date: string
    startTime: string
    endTime: string
    court: number
    reason: string
  }) => void
  onClose: () => void
}

export function BlockTimeModal({ groundId, groundName, onBlock, onClose }: BlockTimeModalProps) {
  const [blockData, setBlockData] = useState({
    date: "",
    startTime: "",
    endTime: "",
    court: "1",
    reason: "",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onBlock({
      groundId,
      date: blockData.date,
      startTime: blockData.startTime,
      endTime: blockData.endTime,
      court: Number(blockData.court),
      reason: blockData.reason,
    })
    onClose()
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="bg-navy text-white rounded-t-lg">
          <CardTitle>Block Time - {groundName}</CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="date">Date</Label>
              <Input
                id="date"
                type="date"
                value={blockData.date}
                onChange={(e) => setBlockData({ ...blockData, date: e.target.value })}
                required
                className="mt-1"
                min={new Date().toISOString().split("T")[0]}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="startTime">Start Time</Label>
                <Input
                  id="startTime"
                  type="time"
                  value={blockData.startTime}
                  onChange={(e) => setBlockData({ ...blockData, startTime: e.target.value })}
                  required
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="endTime">End Time</Label>
                <Input
                  id="endTime"
                  type="time"
                  value={blockData.endTime}
                  onChange={(e) => setBlockData({ ...blockData, endTime: e.target.value })}
                  required
                  className="mt-1"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="court">Court</Label>
              <Select onValueChange={(value) => setBlockData({ ...blockData, court: value })}>
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="Select court" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">Court 1</SelectItem>
                  <SelectItem value="2">Court 2</SelectItem>
                  <SelectItem value="3">Court 3</SelectItem>
                  <SelectItem value="4">Court 4</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="reason">Reason for Blocking</Label>
              <Textarea
                id="reason"
                value={blockData.reason}
                onChange={(e) => setBlockData({ ...blockData, reason: e.target.value })}
                required
                className="mt-1"
                rows={3}
                placeholder="e.g., Maintenance, Private event, Equipment repair..."
              />
            </div>

            <div className="flex gap-4 pt-4">
              <Button type="submit" className="flex-1 bg-orange hover:bg-orange/90 text-white">
                Block Time
              </Button>
              <Button type="button" variant="outline" onClick={onClose} className="flex-1 bg-transparent">
                Cancel
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
