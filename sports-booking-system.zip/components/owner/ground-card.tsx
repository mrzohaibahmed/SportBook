"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

interface Ground {
  id: string
  name: string
  description: string
  address: string
  price: number
  sportType: string
  courts: number
  images: string[]
}

interface GroundCardProps {
  ground: Ground
  onEdit: (ground: Ground) => void
  onDelete: (groundId: string) => void
  onViewBookings: (groundId: string) => void
  onBlockTime: (groundId: string) => void
}

export function GroundCard({ ground, onEdit, onDelete, onViewBookings, onBlockTime }: GroundCardProps) {
  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow duration-300">
      <div className="relative">
        <img src={ground.images[0] || "/placeholder.svg"} alt={ground.name} className="w-full h-48 object-cover" />
        <Badge className="absolute top-3 left-3 bg-orange text-white">{ground.sportType}</Badge>
      </div>
      <CardHeader>
        <CardTitle className="text-navy">{ground.name}</CardTitle>
        <p className="text-sm text-gray-600 line-clamp-2">{ground.description}</p>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-lg font-semibold text-orange">PKR {ground.price}/hour</span>
            <span className="text-sm text-gray-600">{ground.courts} courts</span>
          </div>

          <div className="text-sm text-gray-600">
            <p className="line-clamp-2">📍 {ground.address}</p>
          </div>

          <div className="grid grid-cols-2 gap-2 pt-2">
            <Button
              onClick={() => onViewBookings(ground.id)}
              variant="outline"
              size="sm"
              className="text-accent-blue border-accent-blue hover:bg-accent-blue hover:text-white"
            >
              View Bookings
            </Button>
            <Button
              onClick={() => onBlockTime(ground.id)}
              variant="outline"
              size="sm"
              className="text-accent-purple border-accent-purple hover:bg-accent-purple hover:text-white"
            >
              Block Time
            </Button>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <Button
              onClick={() => onEdit(ground)}
              variant="outline"
              size="sm"
              className="text-navy border-navy hover:bg-navy hover:text-white"
            >
              Edit
            </Button>
            <Button
              onClick={() => onDelete(ground.id)}
              variant="outline"
              size="sm"
              className="text-red-600 border-red-600 hover:bg-red-600 hover:text-white"
            >
              Delete
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
