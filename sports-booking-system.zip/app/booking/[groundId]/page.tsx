"use client"

import { useState, useEffect } from "react"
import { useRouter, useParams } from "next/navigation"
import { useAuth } from "../../auth-context"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { TimeSlotSelector } from "@/components/booking/time-slot-selector"
import { BookingForm } from "@/components/booking/booking-form"
import { BookingConfirmation } from "@/components/booking/booking-confirmation"

interface Ground {
  id: string
  name: string
  description: string
  address: string
  price: number
  sportType: string
  courts: number
  images: string[]
  rating: number
}

interface TimeSlot {
  id: string
  startTime: string
  endTime: string
  isAvailable: boolean
  isBlocked?: boolean
  blockReason?: string
}

interface Court {
  id: number
  name: string
  isAvailable: boolean
}

export default function BookingPage() {
  const { user, logout } = useAuth()
  const router = useRouter()
  const params = useParams()
  const groundId = params.groundId as string

  const [ground, setGround] = useState<Ground | null>(null)
  const [selectedDate, setSelectedDate] = useState("")
  const [timeSlots, setTimeSlots] = useState<TimeSlot[]>([])
  const [courts, setCourts] = useState<Court[]>([])
  const [selectedSlot, setSelectedSlot] = useState<string | null>(null)
  const [selectedCourt, setSelectedCourt] = useState<number | null>(null)
  const [currentStep, setCurrentStep] = useState<"date" | "slot" | "form" | "confirmation">("date")
  const [bookingId, setBookingId] = useState<string | null>(null)

  // Mock data
  useEffect(() => {
    const mockGrounds = [
      {
        id: "1",
        name: "Elite Sports Complex",
        description: "Premium multi-sport facility with state-of-the-art equipment and professional lighting.",
        address: "123 Sports Avenue, Downtown District, City 12345",
        price: 25,
        sportType: "Multi-Sport",
        courts: 4,
        images: ["/modern-indoor-sports-complex-with-multiple-courts.jpg"],
        rating: 4.8,
      },
      {
        id: "2",
        name: "Champions Cricket Arena",
        description: "Professional indoor cricket facility with synthetic pitch and advanced bowling machines.",
        address: "456 Cricket Lane, Sports District, City 12345",
        price: 30,
        sportType: "Cricket",
        courts: 2,
        images: ["/indoor-cricket-pitch-with-professional-lighting.jpg"],
        rating: 4.9,
      },
      {
        id: "3",
        name: "Futsal Pro Center",
        description: "Modern futsal facility with professional-grade flooring and excellent lighting.",
        address: "789 Futsal Street, City Center, City 12345",
        price: 20,
        sportType: "Futsal",
        courts: 3,
        images: ["/professional-futsal-court-with-blue-and-orange-col.jpg"],
        rating: 4.7,
      },
      {
        id: "4",
        name: "Badminton Excellence",
        description: "Dedicated badminton courts with wooden flooring and professional nets.",
        address: "321 Badminton Ave, Sports Zone, City 12345",
        price: 18,
        sportType: "Badminton",
        courts: 4,
        images: ["/badminton-court-with-wooden-flooring-and-nets.jpg"],
        rating: 4.6,
      },
    ]

    const foundGround = mockGrounds.find((g) => g.id === groundId)
    if (foundGround) {
      setGround(foundGround)

      // Generate courts
      const mockCourts: Court[] = Array.from({ length: foundGround.courts }, (_, i) => ({
        id: i + 1,
        name: `Court ${i + 1}`,
        isAvailable: true,
      }))
      setCourts(mockCourts)
    }
  }, [groundId])

  // Generate time slots when date is selected
  useEffect(() => {
    if (selectedDate) {
      const mockTimeSlots: TimeSlot[] = []
      for (let hour = 8; hour < 22; hour++) {
        const startTime = `${hour.toString().padStart(2, "0")}:00`
        const endTime = `${(hour + 1).toString().padStart(2, "0")}:00`
        mockTimeSlots.push({
          id: `${hour}`,
          startTime,
          endTime,
          isAvailable: Math.random() > 0.3, // 70% availability
          isBlocked: Math.random() > 0.9, // 10% blocked
          blockReason: Math.random() > 0.9 ? "Maintenance scheduled" : undefined,
        })
      }
      setTimeSlots(mockTimeSlots)
      setCurrentStep("slot")
    }
  }, [selectedDate])

  // Redirect if not logged in
  useEffect(() => {
    if (!user) {
      router.push("/login")
    }
  }, [user, router])

  if (!user) {
    return null
  }

  if (!ground) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header user={user} onLogout={logout} />
        <main className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-navy mb-4">Ground Not Found</h1>
            <Button onClick={() => router.push("/grounds")} className="bg-orange hover:bg-orange/90 text-white">
              Browse Grounds
            </Button>
          </div>
        </main>
        <Footer />
      </div>
    )
  }

  const handleDateSelect = () => {
    if (selectedDate) {
      setCurrentStep("slot")
    }
  }

  const handleSlotSelect = (slotId: string, courtId: number) => {
    setSelectedSlot(slotId)
    setSelectedCourt(courtId)
  }

  const handleProceedToForm = () => {
    if (selectedSlot && selectedCourt) {
      setCurrentStep("form")
    }
  }

  const handleSubmitBooking = (bookingData: any) => {
    // Simulate booking submission
    const newBookingId = `BK${Date.now()}`
    setBookingId(newBookingId)
    setCurrentStep("confirmation")
  }

  const selectedSlotData = timeSlots.find((slot) => slot.id === selectedSlot)
  const calculatePrice = () => {
    if (!selectedSlotData) return 0
    const start = new Date(`2000-01-01 ${selectedSlotData.startTime}`)
    const end = new Date(`2000-01-01 ${selectedSlotData.endTime}`)
    const hours = (end.getTime() - start.getTime()) / (1000 * 60 * 60)
    return hours * ground.price
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header user={user} onLogout={logout} />
      <main className="flex-1 py-8 bg-muted-gray">
        <div className="container mx-auto px-4">
          {/* Ground Info Header */}
          <Card className="mb-8">
            <CardContent className="p-6">
              <div className="flex items-start gap-6">
                <img
                  src={ground.images[0] || "/placeholder.svg"}
                  alt={ground.name}
                  className="w-32 h-32 object-cover rounded-lg"
                />
                <div className="flex-1">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h1 className="text-3xl font-bold text-navy mb-2">{ground.name}</h1>
                      <div className="flex items-center gap-4 mb-2">
                        <Badge className="bg-orange text-white">{ground.sportType}</Badge>
                        <span className="text-gray-600">⭐ {ground.rating}</span>
                        <span className="text-gray-600">{ground.courts} courts</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-orange">${ground.price}/hour</div>
                    </div>
                  </div>
                  <p className="text-gray-600 mb-2">{ground.description}</p>
                  <p className="text-sm text-gray-500">📍 {ground.address}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Booking Steps */}
          <div className="mb-8">
            <div className="flex items-center justify-center space-x-4">
              {["date", "slot", "form", "confirmation"].map((step, index) => (
                <div key={step} className="flex items-center">
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                      currentStep === step
                        ? "bg-orange text-white"
                        : ["date", "slot", "form", "confirmation"].indexOf(currentStep) > index
                          ? "bg-accent-green text-white"
                          : "bg-gray-300 text-gray-600"
                    }`}
                  >
                    {index + 1}
                  </div>
                  {index < 3 && <div className="w-12 h-0.5 bg-gray-300 mx-2" />}
                </div>
              ))}
            </div>
            <div className="flex justify-center mt-2">
              <div className="text-sm text-gray-600">
                {currentStep === "date" && "Select Date"}
                {currentStep === "slot" && "Choose Time & Court"}
                {currentStep === "form" && "Booking Details"}
                {currentStep === "confirmation" && "Confirmation"}
              </div>
            </div>
          </div>

          {/* Step Content */}
          {currentStep === "date" && (
            <Card className="max-w-md mx-auto">
              <CardHeader>
                <CardTitle className="text-navy">Select Date</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="date">Choose your preferred date</Label>
                  <Input
                    id="date"
                    type="date"
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                    min={new Date().toISOString().split("T")[0]}
                    className="mt-1"
                  />
                </div>
                <Button
                  onClick={handleDateSelect}
                  disabled={!selectedDate}
                  className="w-full bg-orange hover:bg-orange/90 text-white"
                >
                  Continue
                </Button>
              </CardContent>
            </Card>
          )}

          {currentStep === "slot" && (
            <div className="space-y-6">
              <TimeSlotSelector
                selectedDate={selectedDate}
                timeSlots={timeSlots}
                courts={courts}
                pricePerHour={ground.price}
                onSlotSelect={handleSlotSelect}
                selectedSlot={selectedSlot}
                selectedCourt={selectedCourt}
              />
              {selectedSlot && selectedCourt && (
                <div className="text-center">
                  <Button onClick={handleProceedToForm} className="bg-orange hover:bg-orange/90 text-white" size="lg">
                    Proceed to Booking Details
                  </Button>
                </div>
              )}
            </div>
          )}

          {currentStep === "form" && selectedSlotData && (
            <BookingForm
              groundName={ground.name}
              selectedDate={selectedDate}
              selectedSlot={selectedSlotData}
              selectedCourt={selectedCourt!}
              totalPrice={calculatePrice()}
              onSubmitBooking={handleSubmitBooking}
              onCancel={() => setCurrentStep("slot")}
            />
          )}

          {currentStep === "confirmation" && selectedSlotData && bookingId && (
            <BookingConfirmation
              bookingId={bookingId}
              groundName={ground.name}
              groundImage={ground.images[0]}
              selectedDate={selectedDate}
              selectedSlot={selectedSlotData}
              selectedCourt={selectedCourt!}
              totalPrice={calculatePrice()}
              playerName={user.name}
              playerEmail={user.email}
            />
          )}
        </div>
      </main>
      <Footer />
    </div>
  )
}
