"use client"

import { useState, useEffect } from "react"
import { useAuth } from "../auth-context"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { GroundBrowser } from "@/components/player/ground-browser"
import { useRouter } from "next/navigation"

interface Ground {
  id: string
  name: string
  description: string
  address: string
  price: number
  sportType: string
  courts: number
  images: string[]
  rating: number
  isFavorite?: boolean
}

export default function GroundsPage() {
  const { user, logout } = useAuth()
  const router = useRouter()
  const [grounds, setGrounds] = useState<Ground[]>([])

  useEffect(() => {
    const mockGrounds: Ground[] = [
      {
        id: "1",
        name: "Elite Sports Complex",
        description: "Premium multi-sport facility with state-of-the-art equipment and professional lighting.",
        address: "123 Sports Avenue, Downtown District, City 12345",
        price: 25,
        sportType: "Multi-Sport",
        courts: 4,
        images: ["/modern-indoor-sports-complex-with-multiple-courts.jpg"],
        rating: 4.8,
        isFavorite: false,
      },
      {
        id: "2",
        name: "Champions Cricket Arena",
        description: "Professional indoor cricket facility with synthetic pitch and advanced bowling machines.",
        address: "456 Cricket Lane, Sports District, City 12345",
        price: 30,
        sportType: "Cricket",
        courts: 2,
        images: ["/indoor-cricket-pitch-with-professional-lighting.jpg"],
        rating: 4.9,
        isFavorite: false,
      },
      {
        id: "3",
        name: "Futsal Pro Center",
        description: "Modern futsal facility with professional-grade flooring and excellent lighting.",
        address: "789 Futsal Street, City Center, City 12345",
        price: 20,
        sportType: "Futsal",
        courts: 3,
        images: ["/professional-futsal-court-with-blue-and-orange-col.jpg"],
        rating: 4.7,
        isFavorite: false,
      },
      {
        id: "4",
        name: "Badminton Excellence",
        description: "Dedicated badminton courts with wooden flooring and professional nets.",
        address: "321 Badminton Ave, Sports Zone, City 12345",
        price: 18,
        sportType: "Badminton",
        courts: 4,
        images: ["/badminton-court-with-wooden-flooring-and-nets.jpg"],
        rating: 4.6,
        isFavorite: false,
      },
    ]

    setGrounds(mockGrounds)
  }, [])

  const handleBookGround = (groundId: string) => {
    if (!user) {
      router.push("/login")
      return
    }
    router.push(`/booking/${groundId}`)
  }

  const handleToggleFavorite = (groundId: string) => {
    if (!user) {
      router.push("/login")
      return
    }
    setGrounds(
      grounds.map((ground) => (ground.id === groundId ? { ...ground, isFavorite: !ground.isFavorite } : ground)),
    )
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header user={user} onLogout={logout} />
      <main className="flex-1 py-8 bg-muted-gray">
        <div className="container mx-auto px-4">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-navy mb-2">Browse Sports Grounds</h1>
            <p className="text-gray-600">Find the perfect sports facility for your next game</p>
          </div>

          <GroundBrowser grounds={grounds} onBookGround={handleBookGround} onToggleFavorite={handleToggleFavorite} />
        </div>
      </main>
      <Footer />
    </div>
  )
}
