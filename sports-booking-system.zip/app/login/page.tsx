"use client"

import { useRouter } from "next/navigation"
import { useAuth } from "../auth-context"
import { LoginForm } from "@/components/auth/login-form"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"

export default function LoginPage() {
  const { login, user } = useAuth()
  const router = useRouter()

  const handleLogin = async (credentials: { email: string; password: string }) => {
    try {
      await login(credentials)
      // Redirect based on user role will be handled by useEffect in layout
      router.push("/")
    } catch (error) {
      alert("Login failed. Please try again.")
    }
  }

  // Redirect if already logged in
  if (user) {
    router.push(user.role === "owner" ? "/owner-dashboard" : "/player-dashboard")
    return null
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 flex items-center justify-center py-12 bg-muted-gray">
        <LoginForm onLogin={handleLogin} />
      </main>
      <Footer />
    </div>
  )
}
