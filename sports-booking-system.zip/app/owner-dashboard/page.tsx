"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "../auth-context"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { AddGroundForm } from "@/components/owner/add-ground-form"
import { GroundCard } from "@/components/owner/ground-card"
import { BlockTimeModal } from "@/components/owner/block-time-modal"
import { BookingsModal } from "@/components/owner/bookings-modal"
import { EditProfileModal } from "@/components/profile/edit-profile-modal"

interface Ground {
  id: string
  name: string
  description: string
  address: string
  price: number
  sportType: string
  courts: number
  images: string[]
}

interface Booking {
  id: string
  playerName: string
  playerEmail: string
  date: string
  startTime: string
  endTime: string
  court: number
  status: "confirmed" | "pending" | "cancelled"
  totalPrice: number
}

export default function OwnerDashboard() {
  const { user, logout } = useAuth()
  const router = useRouter()
  const [grounds, setGrounds] = useState<Ground[]>([])
  const [showAddForm, setShowAddForm] = useState(false)
  const [selectedGroundForBookings, setSelectedGroundForBookings] = useState<string | null>(null)
  const [selectedGroundForBlocking, setSelectedGroundForBlocking] = useState<{ id: string; name: string } | null>(null)
  const [bookings, setBookings] = useState<Booking[]>([])
  const [showEditProfile, setShowEditProfile] = useState(false)
  const [editingGround, setEditingGround] = useState<Ground | null>(null)

  useEffect(() => {
    const mockGrounds: Ground[] = [
      {
        id: "1",
        name: "Elite Sports Complex",
        description: "Premium multi-sport facility with state-of-the-art equipment and professional lighting.",
        address: "123 Sports Avenue, Downtown District, City 12345",
        price: 25,
        sportType: "Multi-Sport",
        courts: 4,
        images: ["/modern-indoor-sports-complex-with-multiple-courts.jpg"],
      },
      {
        id: "2",
        name: "Champions Cricket Arena",
        description: "Professional indoor cricket facility with synthetic pitch and advanced bowling machines.",
        address: "456 Cricket Lane, Sports District, City 12345",
        price: 30,
        sportType: "Cricket",
        courts: 2,
        images: ["/indoor-cricket-pitch-with-professional-lighting.jpg"],
      },
    ]

    const mockBookings: Booking[] = [
      {
        id: "1",
        playerName: "John Smith",
        playerEmail: "john@example.com",
        date: "2024-01-15",
        startTime: "10:00",
        endTime: "11:00",
        court: 1,
        status: "confirmed",
        totalPrice: 25,
      },
      {
        id: "2",
        playerName: "Sarah Johnson",
        playerEmail: "sarah@example.com",
        date: "2024-01-15",
        startTime: "14:00",
        endTime: "16:00",
        court: 2,
        status: "confirmed",
        totalPrice: 50,
      },
    ]

    setGrounds(mockGrounds)
    setBookings(mockBookings)
  }, [])

  useEffect(() => {
    if (user && user.role !== "owner") {
      router.push("/player-dashboard")
    }
  }, [user, router])

  if (!user || user.role !== "owner") {
    return null
  }

  const handleAddGround = (groundData: Omit<Ground, "id">) => {
    if (editingGround) {
      setGrounds(grounds.map((g) => (g.id === editingGround.id ? { ...groundData, id: editingGround.id } : g)))
      setEditingGround(null)
    } else {
      const newGround: Ground = {
        ...groundData,
        id: Date.now().toString(),
      }
      setGrounds([...grounds, newGround])
    }
    setShowAddForm(false)
  }

  const handleEditGround = (ground: Ground) => {
    setEditingGround(ground)
    setShowAddForm(true)
  }

  const handleDeleteGround = (groundId: string) => {
    if (confirm("Are you sure you want to delete this ground?")) {
      setGrounds(grounds.filter((g) => g.id !== groundId))
    }
  }

  const handleViewBookings = (groundId: string) => {
    setSelectedGroundForBookings(groundId)
  }

  const handleBlockTime = (groundId: string) => {
    const ground = grounds.find((g) => g.id === groundId)
    if (ground) {
      setSelectedGroundForBlocking({ id: groundId, name: ground.name })
    }
  }

  const handleTimeBlock = (blockData: any) => {
    alert(`Time blocked successfully for ${blockData.date} from ${blockData.startTime} to ${blockData.endTime}`)
  }

  const handleUpdateProfile = (updatedUser: any) => {
    alert(`Profile updated successfully! Name: ${updatedUser.name}, Email: ${updatedUser.email}`)
  }

  const handleCancelForm = () => {
    setShowAddForm(false)
    setEditingGround(null)
  }

  const selectedGround = selectedGroundForBookings ? grounds.find((g) => g.id === selectedGroundForBookings) : null
  const groundBookings = selectedGroundForBookings ? bookings.filter((b) => b.id === selectedGroundForBookings) : []

  return (
    <div className="min-h-screen flex flex-col">
      <Header user={user} onLogout={logout} />
      <main className="flex-1 py-8 bg-muted-gray">
        <div className="container mx-auto px-4">
          <div className="mb-8">
            <div className="flex justify-between items-center">
              <div>
                <h1 className="text-3xl font-bold text-navy mb-2">{user.name}'s Dashboard</h1>
                <p className="text-gray-600">Manage your sports facilities and bookings</p>
              </div>
              <Button
                onClick={() => setShowEditProfile(true)}
                variant="outline"
                className="bg-transparent border-navy text-navy hover:bg-navy hover:text-white"
              >
                Edit Profile
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardContent className="p-6 text-center">
                <div className="text-3xl font-bold text-orange mb-2">{grounds.length}</div>
                <div className="text-sm text-gray-600">Total Grounds</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6 text-center">
                <div className="text-3xl font-bold text-accent-blue mb-2">{bookings.length}</div>
                <div className="text-sm text-gray-600">Total Bookings</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6 text-center">
                <div className="text-3xl font-bold text-accent-green mb-2">
                  PKR {bookings.reduce((sum, b) => sum + b.totalPrice, 0)}
                </div>
                <div className="text-sm text-gray-600">Total Revenue</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6 text-center">
                <div className="text-3xl font-bold text-accent-purple mb-2">
                  {grounds.reduce((sum, g) => sum + g.courts, 0)}
                </div>
                <div className="text-sm text-gray-600">Total Courts</div>
              </CardContent>
            </Card>
          </div>

          <div className="mb-8">
            <Button onClick={() => setShowAddForm(true)} className="bg-orange hover:bg-orange/90 text-white" size="lg">
              + Add New Ground
            </Button>
          </div>

          {showAddForm && (
            <div className="mb-8">
              <AddGroundForm onAddGround={handleAddGround} onCancel={handleCancelForm} initialData={editingGround} />
            </div>
          )}

          <div>
            <h2 className="text-2xl font-bold text-navy mb-6">My Grounds</h2>
            {grounds.length === 0 ? (
              <Card>
                <CardContent className="p-12 text-center">
                  <div className="text-gray-500 mb-4">
                    <svg className="w-16 h-16 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={1}
                        d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-4m-5 0H3m2 0h4M9 7h6m-6 4h6m-6 4h6"
                      />
                    </svg>
                  </div>
                  <h3 className="text-xl font-semibold text-gray-700 mb-2">No grounds added yet</h3>
                  <p className="text-gray-500 mb-4">Start by adding your first sports facility</p>
                  <Button onClick={() => setShowAddForm(true)} className="bg-orange hover:bg-orange/90 text-white">
                    Add Your First Ground
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {grounds.map((ground) => (
                  <GroundCard
                    key={ground.id}
                    ground={ground}
                    onEdit={handleEditGround}
                    onDelete={handleDeleteGround}
                    onViewBookings={handleViewBookings}
                    onBlockTime={handleBlockTime}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      </main>
      <Footer />

      {selectedGroundForBookings && selectedGround && (
        <BookingsModal
          groundId={selectedGroundForBookings}
          groundName={selectedGround.name}
          bookings={groundBookings}
          onClose={() => setSelectedGroundForBookings(null)}
        />
      )}

      {selectedGroundForBlocking && (
        <BlockTimeModal
          groundId={selectedGroundForBlocking.id}
          groundName={selectedGroundForBlocking.name}
          onBlock={handleTimeBlock}
          onClose={() => setSelectedGroundForBlocking(null)}
        />
      )}

      {showEditProfile && user && (
        <EditProfileModal user={user} onUpdateProfile={handleUpdateProfile} onClose={() => setShowEditProfile(false)} />
      )}
    </div>
  )
}
