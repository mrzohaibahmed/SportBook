"use client"

import { useRouter } from "next/navigation"
import { useAuth } from "../auth-context"
import { SignupForm } from "@/components/auth/signup-form"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"

export default function SignupPage() {
  const { signup, user } = useAuth()
  const router = useRouter()

  const handleSignup = async (userData: {
    name: string
    email: string
    password: string
    role: "owner" | "player"
  }) => {
    try {
      await signup(userData)
      // Redirect based on user role
      router.push(userData.role === "owner" ? "/owner-dashboard" : "/player-dashboard")
    } catch (error) {
      alert("Signup failed. Please try again.")
    }
  }

  // Redirect if already logged in
  if (user) {
    router.push(user.role === "owner" ? "/owner-dashboard" : "/player-dashboard")
    return null
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 flex items-center justify-center py-12 bg-muted-gray">
        <SignupForm onSignup={handleSignup} />
      </main>
      <Footer />
    </div>
  )
}
