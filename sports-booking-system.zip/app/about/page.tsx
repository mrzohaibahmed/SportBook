"use client"

import { useAuth } from "../auth-context"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function AboutPage() {
  const { user, logout } = useAuth()

  const teamMembers = [
    {
      name: "Sarah Johnson",
      role: "CEO & Founder",
      image: "/placeholder.svg?key=sarah",
      description: "Former professional athlete with 15+ years in sports management.",
    },
    {
      name: "Mike Chen",
      role: "CTO",
      image: "/placeholder.svg?key=mike",
      description: "Tech expert specializing in booking systems and user experience.",
    },
    {
      name: "Emily Rodriguez",
      role: "Head of Operations",
      image: "/placeholder.svg?key=emily",
      description: "Ensures smooth operations and excellent customer service.",
    },
  ]

  const stats = [
    { number: "500+", label: "Sports Facilities" },
    { number: "50K+", label: "Happy Players" },
    { number: "100K+", label: "Bookings Made" },
    { number: "25+", label: "Cities Covered" },
  ]

  return (
    <div className="min-h-screen flex flex-col">
      <Header user={user} onLogout={logout} />
      <main className="flex-1">
        {/* Hero Section */}
        <section className="py-20 bg-navy text-white">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">About SportBook</h1>
            <p className="text-xl md:text-2xl text-gray-200 max-w-3xl mx-auto">
              We're revolutionizing how people discover and book sports facilities, making it easier than ever to play
              your favorite sports.
            </p>
          </div>
        </section>

        {/* Mission Section */}
        <section className="py-20 bg-white">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto text-center">
              <h2 className="text-3xl md:text-4xl font-bold text-navy mb-8">Our Mission</h2>
              <p className="text-lg text-gray-600 mb-12">
                At SportBook, we believe everyone deserves access to quality sports facilities. Our platform connects
                players with the best indoor sports venues, making booking simple, transparent, and reliable.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <Card className="text-center hover:shadow-lg transition-shadow">
                  <CardContent className="p-8">
                    <div className="text-4xl text-orange mb-4">🎯</div>
                    <h3 className="text-xl font-semibold text-navy mb-3">Accessibility</h3>
                    <p className="text-gray-600">Making sports facilities accessible to everyone, everywhere.</p>
                  </CardContent>
                </Card>

                <Card className="text-center hover:shadow-lg transition-shadow">
                  <CardContent className="p-8">
                    <div className="text-4xl text-orange mb-4">⚡</div>
                    <h3 className="text-xl font-semibold text-navy mb-3">Simplicity</h3>
                    <p className="text-gray-600">Streamlined booking process that takes just minutes.</p>
                  </CardContent>
                </Card>

                <Card className="text-center hover:shadow-lg transition-shadow">
                  <CardContent className="p-8">
                    <div className="text-4xl text-orange mb-4">🤝</div>
                    <h3 className="text-xl font-semibold text-navy mb-3">Community</h3>
                    <p className="text-gray-600">Building stronger sports communities through better connections.</p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="py-20 bg-muted-gray">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-navy mb-4">Our Impact</h2>
              <p className="text-xl text-gray-600">Numbers that showcase our growing community</p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              {stats.map((stat, index) => (
                <Card key={index} className="text-center">
                  <CardContent className="p-8">
                    <div className="text-4xl font-bold text-orange mb-2">{stat.number}</div>
                    <div className="text-gray-600">{stat.label}</div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Team Section */}
        <section className="py-20 bg-white">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-navy mb-4">Meet Our Team</h2>
              <p className="text-xl text-gray-600">The passionate people behind SportBook</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
              {teamMembers.map((member, index) => (
                <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                  <CardContent className="p-8">
                    <img
                      src={member.image || "/placeholder.svg"}
                      alt={member.name}
                      className="w-24 h-24 rounded-full mx-auto mb-4 object-cover"
                    />
                    <h3 className="text-xl font-semibold text-navy mb-2">{member.name}</h3>
                    <p className="text-orange font-medium mb-3">{member.role}</p>
                    <p className="text-gray-600 text-sm">{member.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-navy text-white">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Get Started?</h2>
            <p className="text-xl text-gray-200 mb-8 max-w-2xl mx-auto">
              Join thousands of players who have already discovered their perfect sports facilities through SportBook.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/grounds">
                <Button size="lg" className="bg-orange hover:bg-orange/90 text-white px-8">
                  Browse Grounds
                </Button>
              </Link>
              <Link href="/signup">
                <Button
                  size="lg"
                  variant="outline"
                  className="border-white text-white hover:bg-white hover:text-navy px-8 bg-transparent"
                >
                  Sign Up Today
                </Button>
              </Link>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
