"use client"

import { useAuth } from "./auth-context"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { HeroSection } from "@/components/homepage/hero-section"
import { FeaturesSection } from "@/components/homepage/features-section"
import { PopularGrounds } from "@/components/homepage/popular-grounds"
import { AIRecommendation } from "@/components/homepage/ai-recommendation"
import { Chatbot } from "@/components/chatbot/chatbot"

export default function HomePage() {
  const { user, logout } = useAuth()

  return (
    <div className="min-h-screen flex flex-col">
      <Header user={user} onLogout={logout} />
      <main className="flex-1">
        <HeroSection />
        <FeaturesSection />
        <PopularGrounds />
        <AIRecommendation />
      </main>
      <Footer />
      <Chatbot />
    </div>
  )
}
