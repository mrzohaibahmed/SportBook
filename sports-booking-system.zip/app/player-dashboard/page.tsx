"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "../auth-context"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { FavoritesSection } from "@/components/player/favorites-section"
import { MyBookings } from "@/components/player/my-bookings"
import { ReviewModal } from "@/components/player/review-modal"
import { EditProfileModal } from "@/components/profile/edit-profile-modal"
import { Button } from "@/components/ui/button"

interface Ground {
  id: string
  name: string
  description: string
  address: string
  price: number
  sportType: string
  courts: number
  images: string[]
  rating: number
  isFavorite?: boolean
}

interface Booking {
  id: string
  groundId: string
  groundName: string
  groundImage: string
  date: string
  startTime: string
  endTime: string
  court: number
  status: "confirmed" | "pending" | "cancelled" | "completed"
  totalPrice: number
  canReview?: boolean
}

export default function PlayerDashboard() {
  const { user, logout } = useAuth()
  const router = useRouter()
  const [grounds, setGrounds] = useState<Ground[]>([])
  const [bookings, setBookings] = useState<Booking[]>([])
  const [reviewModal, setReviewModal] = useState<{ groundId: string; groundName: string } | null>(null)
  const [showEditProfile, setShowEditProfile] = useState(false)

  // Mock data for demonstration
  useEffect(() => {
    const mockGrounds: Ground[] = [
      {
        id: "1",
        name: "Elite Sports Complex",
        description: "Premium multi-sport facility with state-of-the-art equipment and professional lighting.",
        address: "123 Sports Avenue, Downtown District, City 12345",
        price: 25,
        sportType: "Multi-Sport",
        courts: 4,
        images: ["/modern-indoor-sports-complex-with-multiple-courts.jpg"],
        rating: 4.8,
        isFavorite: true,
      },
      {
        id: "2",
        name: "Champions Cricket Arena",
        description: "Professional indoor cricket facility with synthetic pitch and advanced bowling machines.",
        address: "456 Cricket Lane, Sports District, City 12345",
        price: 30,
        sportType: "Cricket",
        courts: 2,
        images: ["/indoor-cricket-pitch-with-professional-lighting.jpg"],
        rating: 4.9,
        isFavorite: false,
      },
      {
        id: "3",
        name: "Futsal Pro Center",
        description: "Modern futsal facility with professional-grade flooring and excellent lighting.",
        address: "789 Futsal Street, City Center, City 12345",
        price: 20,
        sportType: "Futsal",
        courts: 3,
        images: ["/professional-futsal-court-with-blue-and-orange-col.jpg"],
        rating: 4.7,
        isFavorite: true,
      },
      {
        id: "4",
        name: "Badminton Excellence",
        description: "Dedicated badminton courts with wooden flooring and professional nets.",
        address: "321 Badminton Ave, Sports Zone, City 12345",
        price: 18,
        sportType: "Badminton",
        courts: 4,
        images: ["/badminton-court-with-wooden-flooring-and-nets.jpg"],
        rating: 4.6,
        isFavorite: false,
      },
    ]

    const mockBookings: Booking[] = [
      {
        id: "1",
        groundId: "1",
        groundName: "Elite Sports Complex",
        groundImage: "/modern-indoor-sports-complex-with-multiple-courts.jpg",
        date: "2024-01-20",
        startTime: "10:00",
        endTime: "11:00",
        court: 1,
        status: "confirmed",
        totalPrice: 25,
      },
      {
        id: "2",
        groundId: "2",
        groundName: "Champions Cricket Arena",
        groundImage: "/indoor-cricket-pitch-with-professional-lighting.jpg",
        date: "2024-01-15",
        startTime: "14:00",
        endTime: "16:00",
        court: 1,
        status: "completed",
        totalPrice: 60,
        canReview: true,
      },
      {
        id: "3",
        groundId: "3",
        groundName: "Futsal Pro Center",
        groundImage: "/professional-futsal-court-with-blue-and-orange-col.jpg",
        date: "2024-01-25",
        startTime: "18:00",
        endTime: "19:00",
        court: 2,
        status: "pending",
        totalPrice: 20,
      },
    ]

    setGrounds(mockGrounds)
    setBookings(mockBookings)
  }, [])

  // Redirect if not player
  useEffect(() => {
    if (user && user.role !== "player") {
      router.push("/owner-dashboard")
    }
  }, [user, router])

  if (!user || user.role !== "player") {
    return null
  }

  const favoriteGrounds = grounds.filter((ground) => ground.isFavorite)

  const handleBookGround = (groundId: string) => {
    router.push(`/booking/${groundId}`)
  }

  const handleToggleFavorite = (groundId: string) => {
    setGrounds(
      grounds.map((ground) => (ground.id === groundId ? { ...ground, isFavorite: !ground.isFavorite } : ground)),
    )
  }

  const handleCancelBooking = (bookingId: string) => {
    if (confirm("Are you sure you want to cancel this booking?")) {
      setBookings(
        bookings.map((booking) => (booking.id === bookingId ? { ...booking, status: "cancelled" as const } : booking)),
      )
    }
  }

  const handleLeaveReview = (groundId: string, groundName: string) => {
    setReviewModal({ groundId, groundName })
  }

  const handleSubmitReview = (review: { groundId: string; rating: number; comment: string }) => {
    // In a real app, this would submit to the backend
    alert(`Review submitted for ${review.groundId}: ${review.rating} stars - ${review.comment}`)

    // Mark booking as reviewed
    setBookings(
      bookings.map((booking) =>
        booking.groundId === review.groundId && booking.canReview ? { ...booking, canReview: false } : booking,
      ),
    )
  }

  const handleUpdateProfile = (updatedUser: any) => {
    // In a real app, this would update the user in the backend and auth context
    alert(`Profile updated successfully! Name: ${updatedUser.name}, Email: ${updatedUser.email}`)
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header user={user} onLogout={logout} />
      <main className="flex-1 py-8 bg-muted-gray">
        <div className="container mx-auto px-4">
          <div className="mb-8">
            <div className="flex justify-between items-center">
              <div>
                <h1 className="text-3xl font-bold text-navy mb-2">{user.name}'s Dashboard</h1>
                <p className="text-gray-600">Manage your favorites and bookings</p>
              </div>
              <Button
                onClick={() => setShowEditProfile(true)}
                variant="outline"
                className="bg-transparent border-navy text-navy hover:bg-navy hover:text-white"
              >
                Edit Profile
              </Button>
            </div>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardContent className="p-6 text-center">
                <div className="text-3xl font-bold text-orange mb-2">{bookings.length}</div>
                <div className="text-sm text-gray-600">Total Bookings</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6 text-center">
                <div className="text-3xl font-bold text-accent-blue mb-2">
                  {bookings.filter((b) => b.status === "confirmed").length}
                </div>
                <div className="text-sm text-gray-600">Upcoming</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6 text-center">
                <div className="text-3xl font-bold text-accent-green mb-2">{favoriteGrounds.length}</div>
                <div className="text-sm text-gray-600">Favorites</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6 text-center">
                <div className="text-3xl font-bold text-accent-purple mb-2">
                  PKR {bookings.reduce((sum, b) => sum + b.totalPrice, 0)}
                </div>
                <div className="text-sm text-gray-600">Total Spent</div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content Tabs */}
          <Tabs defaultValue="favorites" className="space-y-6">
            <TabsList className="grid w-full grid-cols-2 bg-white">
              <TabsTrigger value="favorites" className="data-[state=active]:bg-navy data-[state=active]:text-white">
                My Favorites
              </TabsTrigger>
              <TabsTrigger value="bookings" className="data-[state=active]:bg-navy data-[state=active]:text-white">
                My Bookings
              </TabsTrigger>
            </TabsList>

            <TabsContent value="favorites">
              <FavoritesSection
                favoriteGrounds={favoriteGrounds}
                onBookGround={handleBookGround}
                onRemoveFavorite={handleToggleFavorite}
              />
            </TabsContent>

            <TabsContent value="bookings">
              <MyBookings bookings={bookings} onCancelBooking={handleCancelBooking} onLeaveReview={handleLeaveReview} />
            </TabsContent>
          </Tabs>
        </div>
      </main>
      <Footer />

      {/* Review Modal */}
      {reviewModal && (
        <ReviewModal
          groundId={reviewModal.groundId}
          groundName={reviewModal.groundName}
          onSubmitReview={handleSubmitReview}
          onClose={() => setReviewModal(null)}
        />
      )}

      {/* Edit Profile Modal */}
      {showEditProfile && user && (
        <EditProfileModal user={user} onUpdateProfile={handleUpdateProfile} onClose={() => setShowEditProfile(false)} />
      )}
    </div>
  )
}
