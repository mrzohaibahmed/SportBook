"use client"

import { useAuth } from "../auth-context"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function PrivacyPage() {
  const { user, logout } = useAuth()

  return (
    <div className="min-h-screen flex flex-col">
      <Header user={user} onLogout={logout} />
      <main className="flex-1 py-12 bg-muted-gray">
        <div className="container mx-auto px-4 max-w-4xl">
          <Card>
            <CardHeader className="bg-navy text-white rounded-t-lg">
              <CardTitle className="text-3xl">Privacy Policy</CardTitle>
              <p className="text-gray-200">Last updated: January 2024</p>
            </CardHeader>
            <CardContent className="p-8 space-y-8">
              <section>
                <h2 className="text-2xl font-bold text-navy mb-4">1. Information We Collect</h2>
                <div className="space-y-3 text-gray-600">
                  <p>
                    <strong>Personal Information:</strong> Name, email address, phone number, and payment information
                  </p>
                  <p>
                    <strong>Usage Data:</strong> Information about how you use our platform, including booking history
                    and preferences
                  </p>
                  <p>
                    <strong>Device Information:</strong> IP address, browser type, and device identifiers
                  </p>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-navy mb-4">2. How We Use Your Information</h2>
                <div className="space-y-3 text-gray-600">
                  <p>• To process bookings and payments</p>
                  <p>• To communicate with you about your bookings</p>
                  <p>• To improve our services and user experience</p>
                  <p>• To send promotional materials (with your consent)</p>
                  <p>• To comply with legal obligations</p>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-navy mb-4">3. Information Sharing</h2>
                <p className="text-gray-600 leading-relaxed">
                  We do not sell, trade, or otherwise transfer your personal information to third parties without your
                  consent, except as described in this policy. We may share information with:
                </p>
                <div className="space-y-3 text-gray-600 mt-4">
                  <p>• Sports facility owners (for booking purposes)</p>
                  <p>• Payment processors (for transaction processing)</p>
                  <p>• Service providers who assist in our operations</p>
                  <p>• Legal authorities when required by law</p>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-navy mb-4">4. Data Security</h2>
                <p className="text-gray-600 leading-relaxed">
                  We implement appropriate security measures to protect your personal information against unauthorized
                  access, alteration, disclosure, or destruction. This includes encryption of sensitive data and regular
                  security assessments.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-navy mb-4">5. Your Rights</h2>
                <div className="space-y-3 text-gray-600">
                  <p>• Access your personal information</p>
                  <p>• Correct inaccurate information</p>
                  <p>• Delete your account and associated data</p>
                  <p>• Opt-out of marketing communications</p>
                  <p>• Data portability (receive a copy of your data)</p>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-navy mb-4">6. Cookies</h2>
                <p className="text-gray-600 leading-relaxed">
                  We use cookies and similar technologies to enhance your experience, analyze usage patterns, and
                  personalize content. You can control cookie settings through your browser preferences.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-navy mb-4">7. Contact Us</h2>
                <p className="text-gray-600 leading-relaxed">
                  If you have questions about this Privacy Policy or want to exercise your rights, please contact us at{" "}
                  <a href="mailto:privacy@sportbook.com" className="text-orange hover:underline">
                    privacy@sportbook.com
                  </a>
                </p>
              </section>
            </CardContent>
          </Card>
        </div>
      </main>
      <Footer />
    </div>
  )
}
