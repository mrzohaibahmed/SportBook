"use client"

import { useAuth } from "../auth-context"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function TermsPage() {
  const { user, logout } = useAuth()

  return (
    <div className="min-h-screen flex flex-col">
      <Header user={user} onLogout={logout} />
      <main className="flex-1 py-12 bg-muted-gray">
        <div className="container mx-auto px-4 max-w-4xl">
          <Card>
            <CardHeader className="bg-navy text-white rounded-t-lg">
              <CardTitle className="text-3xl">Terms and Conditions</CardTitle>
              <p className="text-gray-200">Last updated: January 2024</p>
            </CardHeader>
            <CardContent className="p-8 space-y-8">
              <section>
                <h2 className="text-2xl font-bold text-navy mb-4">1. Acceptance of Terms</h2>
                <p className="text-gray-600 leading-relaxed">
                  By accessing and using SportBook, you accept and agree to be bound by the terms and provision of this
                  agreement. If you do not agree to abide by the above, please do not use this service.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-navy mb-4">2. Booking and Payment</h2>
                <div className="space-y-3 text-gray-600">
                  <p>• All bookings must be paid in full at the time of reservation</p>
                  <p>• Prices are subject to change without notice</p>
                  <p>• Payment is processed securely through our payment partners</p>
                  <p>• Receipts will be provided via email after successful payment</p>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-navy mb-4">3. Cancellation Policy</h2>
                <div className="space-y-3 text-gray-600">
                  <p>• Cancellations must be made at least 2 hours before the scheduled time</p>
                  <p>• Refunds will be processed within 5-7 business days</p>
                  <p>• No-shows will not be eligible for refunds</p>
                  <p>• Emergency cancellations may be considered on a case-by-case basis</p>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-navy mb-4">4. User Responsibilities</h2>
                <div className="space-y-3 text-gray-600">
                  <p>• Users must arrive on time for their bookings</p>
                  <p>• Proper sports attire and equipment are required</p>
                  <p>• Users must follow facility rules and regulations</p>
                  <p>• Any damage to facilities may result in additional charges</p>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-navy mb-4">5. Liability</h2>
                <p className="text-gray-600 leading-relaxed">
                  SportBook acts as a platform connecting users with sports facilities. We are not liable for any
                  injuries, accidents, or damages that may occur during the use of booked facilities. Users participate
                  in sports activities at their own risk.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-navy mb-4">6. Privacy</h2>
                <p className="text-gray-600 leading-relaxed">
                  Your privacy is important to us. Please review our Privacy Policy, which also governs your use of the
                  Service, to understand our practices.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-navy mb-4">7. Contact Information</h2>
                <p className="text-gray-600 leading-relaxed">
                  If you have any questions about these Terms and Conditions, please contact us at{" "}
                  <a href="mailto:legal@sportbook.com" className="text-orange hover:underline">
                    legal@sportbook.com
                  </a>
                </p>
              </section>
            </CardContent>
          </Card>
        </div>
      </main>
      <Footer />
    </div>
  )
}
